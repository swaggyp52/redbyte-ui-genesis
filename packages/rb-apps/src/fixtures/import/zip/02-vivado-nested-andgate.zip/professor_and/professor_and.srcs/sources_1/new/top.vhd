library ieee;
use ieee.std_logic_1164.all;

entity top is
  port (
    sw0 : in  std_logic;
    sw1 : in  std_logic;
    ld0 : out std_logic
  );
end top;

architecture rtl of top is
begin
  ld0 <= sw0 and sw1;
end rtl;
