## Switch Inputs
set_property PACKAGE_PIN V17 [get_ports {sw0}]
set_property PACKAGE_PIN V16 [get_ports {sw1}]
## LED Output
set_property PACKAGE_PIN U16 [get_ports {ld0}]
