## Switch Inputs
set_property PACKAGE_PIN V17 [get_ports {a}]
set_property PACKAGE_PIN V16 [get_ports {b}]
## LED Output
set_property PACKAGE_PIN U16 [get_ports {y}]
