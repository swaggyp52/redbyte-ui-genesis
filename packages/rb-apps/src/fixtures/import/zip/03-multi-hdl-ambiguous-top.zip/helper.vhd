library ieee;
use ieee.std_logic_1164.all;

entity helper_buf is
end helper_buf;

architecture rtl of helper_buf is
begin
end rtl;
