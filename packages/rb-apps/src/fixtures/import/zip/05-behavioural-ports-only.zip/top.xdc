## Clock
set_property PACKAGE_PIN W5 [get_ports {clk}]
## Data input
set_property PACKAGE_PIN V17 [get_ports {d}]
## Output
set_property PACKAGE_PIN U16 [get_ports {q}]
