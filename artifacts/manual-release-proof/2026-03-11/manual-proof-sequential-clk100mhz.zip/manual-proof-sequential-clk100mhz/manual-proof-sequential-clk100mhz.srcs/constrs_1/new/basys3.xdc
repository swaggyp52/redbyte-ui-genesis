# RedByte Basys3 Constraints (deterministic)
# Generated for top module: top

## Inputs
set_property -dict { PACKAGE_PIN W5 IOSTANDARD LVCMOS33 } [get_ports {port_clk_out}]
create_clock -period 10.000 -name sys_clk -waveform {0.000 5.000} [get_ports {port_clk_out}]
set_property -dict { PACKAGE_PIN V16 IOSTANDARD LVCMOS33 } [get_ports {port_count_en_out}]
set_property -dict { PACKAGE_PIN V17 IOSTANDARD LVCMOS33 } [get_ports {port_rst_out}]

## Outputs
set_property -dict { PACKAGE_PIN U16 IOSTANDARD LVCMOS33 } [get_ports {port_out_q0_in}]
set_property -dict { PACKAGE_PIN E19 IOSTANDARD LVCMOS33 } [get_ports {port_out_q1_in}]
set_property -dict { PACKAGE_PIN U19 IOSTANDARD LVCMOS33 } [get_ports {port_out_q2_in}]
set_property -dict { PACKAGE_PIN V19 IOSTANDARD LVCMOS33 } [get_ports {port_out_q3_in}]