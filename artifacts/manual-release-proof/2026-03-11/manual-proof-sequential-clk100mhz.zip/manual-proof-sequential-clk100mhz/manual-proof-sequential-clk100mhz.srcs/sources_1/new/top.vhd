library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity top is
  Port (
    port_clk_out : in  STD_LOGIC;
    port_count_en_out : in  STD_LOGIC;
    port_rst_out : in  STD_LOGIC;
    port_out_q0_in : out STD_LOGIC;
    port_out_q1_in : out STD_LOGIC;
    port_out_q2_in : out STD_LOGIC;
    port_out_q3_in : out STD_LOGIC
  );
end entity top;

architecture rtl of top is
begin
  port_out_q0_in <= '0'; -- undriven output
  port_out_q1_in <= '0'; -- undriven output
  port_out_q2_in <= '0'; -- undriven output
  port_out_q3_in <= '0'; -- undriven output
end architecture rtl;