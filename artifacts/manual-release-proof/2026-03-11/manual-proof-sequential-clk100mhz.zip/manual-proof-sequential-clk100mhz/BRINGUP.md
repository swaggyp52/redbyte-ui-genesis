# Basys3 Bring-Up
- Project: manual-proof-sequential-clk100mhz
- Board: Basys3 (xc7a35tcpg236-1)
- Export Hash: 0000000053686ca6
- Verify Hash: pending

## Steps
1. Extract bundle contents.
2. Run: vivado -mode batch -source vivado_import.tcl
3. Generate/program bitstream in Vivado.
4. Validate outputs against EXPECTED_IO.json.

## Expected Behavior
- Manual release proof fixture: sequential design with CLK100MHZ.

## Signal Mapping
- clk -> CLK100MHZ
- count_en -> SW1
- q0 -> LD0
- q1 -> LD1