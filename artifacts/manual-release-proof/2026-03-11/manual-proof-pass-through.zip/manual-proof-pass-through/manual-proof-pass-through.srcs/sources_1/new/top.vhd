library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity top is
  Port (
    sw0_out : in  STD_LOGIC;
    ld0_in : out STD_LOGIC
  );
end entity top;

architecture rtl of top is
begin
  ld0_in <= sw0_out;
end architecture rtl;