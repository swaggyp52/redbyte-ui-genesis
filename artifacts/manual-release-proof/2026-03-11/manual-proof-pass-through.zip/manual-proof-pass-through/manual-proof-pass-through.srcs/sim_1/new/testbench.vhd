library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_top is
end entity tb_top;

architecture sim of tb_top is
  component top is
    port (
      sw0_out : in  std_logic;
      ld0_in : out std_logic
    );
  end component;

  signal sw0_out : std_logic := '0';
  signal ld0_in : std_logic;
begin
  -- Deterministic schedule contract with Verify runner:
  -- schedule=combinational
  -- reason=combinational
  -- sequence=single-tick
  dut: top
    port map (
      sw0_out => sw0_out,
      ld0_in => ld0_in
    );

  stim: process
  begin
    -- Vector 0 (tick=0)
    sw0_out <= '0';
    wait for 0 ns;
    assert ld0_in = '0'
      report "Vector 0 failed on ld0_in: expected '0', got " & std_logic'image(ld0_in)
      severity error;

    -- Vector 1 (tick=1)
    sw0_out <= '1';
    wait for 0 ns;
    assert ld0_in = '1'
      report "Vector 1 failed on ld0_in: expected '1', got " & std_logic'image(ld0_in)
      severity error;

    wait;
  end process;
end architecture sim;