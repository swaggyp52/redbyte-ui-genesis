# RedByte Basys3 Constraints (deterministic)
# Generated for top module: top

## Inputs
set_property -dict { PACKAGE_PIN V17 IOSTANDARD LVCMOS33 } [get_ports {sw0_out}]

## Outputs
set_property -dict { PACKAGE_PIN U16 IOSTANDARD LVCMOS33 } [get_ports {ld0_in}]