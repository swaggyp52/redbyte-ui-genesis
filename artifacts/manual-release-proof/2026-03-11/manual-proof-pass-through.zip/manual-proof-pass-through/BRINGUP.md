# Basys3 Bring-Up
- Project: manual-proof-pass-through
- Board: Basys3 (xc7a35tcpg236-1)
- Export Hash: 00000000081f8b60
- Verify Hash: pending

## Steps
1. Extract bundle contents.
2. Run: vivado -mode batch -source vivado_import.tcl
3. Generate/program bitstream in Vivado.
4. Validate outputs against EXPECTED_IO.json.

## Expected Behavior
- Manual release proof fixture: SW0 -> LD0 pass-through.

## Signal Mapping
- ld0 -> LD0
- sw0 -> SW0