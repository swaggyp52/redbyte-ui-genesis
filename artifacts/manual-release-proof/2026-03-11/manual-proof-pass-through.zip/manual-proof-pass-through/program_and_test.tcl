# RedByte Basys3 program-and-test scaffold
set project_name "manual_proof_pass_through"
set top_module "top"
set project_dir [pwd]
set bitstream_path [file normalize [file join $project_dir "${project_name}.runs" "impl_1" "${top_module}.bit"]]

open_hw_manager
connect_hw_server
open_hw_target
set device [lindex [get_hw_devices] 0]
current_hw_device $device
refresh_hw_device $device
# set_property PROGRAM.FILE $bitstream_path $device
# program_hw_devices $device
puts "Update bitstream_path if needed, then uncomment PROGRAM.FILE/program commands."