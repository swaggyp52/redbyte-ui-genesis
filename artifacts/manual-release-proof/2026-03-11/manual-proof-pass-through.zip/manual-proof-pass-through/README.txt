RedByte Vivado Project Folder (Open Project)

Project: manual-proof-pass-through
Board: Basys3
Part: xc7a35tcpg236-1
Top module: top
Tool: Vivado 2024.1+

Recommended student flow:
1. Unzip the download so the folder "manual-proof-pass-through" is visible.
2. Open Vivado.
3. Click "Open Project" and select "manual-proof-pass-through.xpr".
4. Confirm the part, top module, design sources, and constraints are loaded.
5. Run Synthesis, Run Implementation, then Generate Bitstream.
6. Open Hardware Manager and program the Basys3.

Fallback:
If Open Project is blocked on your machine, run:
  vivado -mode batch -source vivado_import.tcl -notrace -nojournal -log vivado_import.log

Important:
- The exported constraints file is "basys3.xdc" and assumes top-level HDL port names match the generated XDC get_ports names.
- RedByte generated this folder deterministically from the project manifest.
- The project includes testbench.vhd under sim_1 for behavioral simulation.
